/* hello.c */

int printf();

int main(void)
{
    printf("hello world\n");
}
